declare namespace Rx {
  interface NodeList {}
  interface Node {}
}
