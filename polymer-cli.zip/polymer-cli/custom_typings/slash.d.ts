declare module 'slash' {
  export function slash(source: string): string;
}
