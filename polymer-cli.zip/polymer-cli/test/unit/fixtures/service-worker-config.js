module.exports = {
  staticFileGlobs: ['*'],
}